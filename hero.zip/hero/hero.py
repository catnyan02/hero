import os
import pygame
import random as r


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname)
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


pygame.init()
width, height = 300, 300
size = width, height
screen = pygame.display.set_mode(size)
screen.fill((r.randint(0, 255), r.randint(0, 255), r.randint(0, 255)))

all_sprites = pygame.sprite.Group()
image = load_image('creature.png', -1)
creature = pygame.sprite.Sprite(all_sprites)
creature.image = image
creature.rect = creature.image.get_rect()
creature.rect.topleft = 0, 0
delta = 10

running = True
while running:
    keys = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if keys[pygame.K_DOWN]:
            creature.rect.top += delta
        if keys[pygame.K_UP]:
            creature.rect.top -= delta
        if keys[pygame.K_RIGHT]:
            creature.rect.left += delta
        if keys[pygame.K_LEFT]:
            creature.rect.left -= delta
    all_sprites.draw(screen)
    pygame.display.flip()
    screen.fill((r.randint(0, 255), r.randint(0, 255), r.randint(0, 255)))
pygame.quit()